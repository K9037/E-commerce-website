from django.contrib import admin
from .models import resell_book
# Register your models here.

admin.site.register(resell_book)
