from django.urls import path
from contact.views import *

urlpatterns = [
    path('contact', contact_view),
]